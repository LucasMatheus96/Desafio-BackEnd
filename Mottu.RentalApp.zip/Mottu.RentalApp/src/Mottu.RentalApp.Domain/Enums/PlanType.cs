﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mottu.RentalApp.Domain.Enums
{
    public enum PlanType
    {
        D7 = 7,
        D15 = 15,
        D30 = 30,
        D45 = 45,
        D50 = 50 
    }
}
