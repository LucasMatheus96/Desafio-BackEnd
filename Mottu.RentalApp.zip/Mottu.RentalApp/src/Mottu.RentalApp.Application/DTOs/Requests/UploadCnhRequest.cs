﻿namespace Mottu.RentalApp.Application.DTOs.Requests
{
    public class UploadCnhRequest
    {
        public string ImagemCnh { get; init; } = default!;
    }
}
