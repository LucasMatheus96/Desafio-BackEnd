﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Mottu.RentalApp.Application.DTOs.Responses
{
    public class ErrorResponse
    {
        [JsonPropertyName("Mensagem")]
        public string ErrorMessage { get; set; } = default!;

    }
}
