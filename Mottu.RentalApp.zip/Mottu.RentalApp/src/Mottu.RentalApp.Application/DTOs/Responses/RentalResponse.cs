﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mottu.RentalApp.Application.DTOs.Responses
{
    public class RentalResponse
    {
        public Guid Id { get; set; }
    }
}
